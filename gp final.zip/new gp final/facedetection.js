//variables
var detector;
var classifier = objectdetect.frontalface;
var detectorImg;
var faces;

//set width and height variables
var w = 160;
var h = 120;


//set up face detection
function setupFaceDetect(){
    detectorImg = createCapture(VIDEO);
    detectorImg.size(w,h);
    detectorImg.hide();
    
    var scaleFactor = 1.2;
    detector = new objectdetect.detector(w, h, scaleFactor, classifier);
}

//draw face detection
function drawFaceDetect(){
    //if game started
    if (startGame){
        //draw the video
        image(detectorImg,500,1140,w,h);
        //detect the faces
        faces = detectFaces(detectorImg)
        
        strokeWeight(2);
        stroke(255);
        noFill();
        
        for (var i=0; i<faces.length; i++){
            var face=faces[i];
            if (face[4] > 4){
                //if face detected draw the basket image at face
                image(basket,face[0]+500, face[1] +1140, 50,50);
                playerX = face[0]+500;
                playerY = face[1]+1140;
            }
        }
    }
    
    
    //if no effect
    if (currentEffect === 'none'){
        image(snapshot,500,670,w,h);
        faces = detectFaces(snapshot);
    
        for (var i=0; i<faces.length; i++){
            var face=faces[i];
            if (face[4] > 4){
                //if face detected draw rectangle at face
                strokeWeight(2);
                stroke(255);
                noFill();
                rect(face[0]+500, face[1] +670, face[2], face[3]);
                snapshot.updatePixels();
                
            }
        }
    // if greyscale effect
    } else if (currentEffect === 'grayscale') {
        // Display the original snapshot
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];
    
                // Create a temporary image of the detected face area
                var faceImage = snapshot.get(x, y, faceWidth, faceHeight);
    
                image(greyScale(faceImage,5), x+500, y+670);
            }
        }
    //if blurred effect
    } else if (currentEffect === 'blurred') {
        // Display the original snapshot
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];
    
                // Create a temporary image of the detected face area
                var faceImage = snapshot.get(x, y, faceWidth, faceHeight);
    
                // Apply blur effect to the temporary image
                // Draw the blurred face area onto the main canvas
                image(blurImage(faceImage,5), x+500, y+670);
            }
        }
    
    //if ycbcr effect
    } else if (currentEffect === 'ycbcr') {
        // Display the original snapshot
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];
    
                // Create a temporary image of the detected face area
                var faceImage = snapshot.get(x, y, faceWidth, faceHeight);
                //apply ycbcr filter
                image(applyYCbCrFilter(faceImage,5), x+500, y+670);
            }
        }
    //if pixelate effect
    } else if (currentEffect === 'pixelate') {
        // Display the original snapshot
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];
    
                // Create a temporary image of the detected face area
                var faceImage = snapshot.get(x, y, faceWidth, faceHeight);
    
                // Apply pixelate effect to the temporary image
                image(pixelate(faceImage), x+500, y+670);
            }
        }
    //if hat filter
    } else if (currentEffect === 'Hat'){
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];

    
                // Apply pixelate effect to the temporary image
                image(hat, x+490, y+640, faceWidth*1.2, faceHeight*0.8);
            }
        }
    } else if (currentEffect === 'ears'){
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];

    
                // Apply pixelate effect to the temporary image
                image(ears, x+495, y+625, faceWidth*1.2, faceHeight*1.2);
            }
        }
    } else if (currentEffect === 'dog'){
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];

    
                // Apply pixelate effect to the temporary image
                image(dog, x+492, y+635, faceWidth*1.3, faceHeight*1.3);
            }
        }
    } else if (currentEffect === 'flower'){
        image(snapshot, 500, 670, w, h);
    
        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
    
        // Loop through each detected face
        for (var i = 0; i < faces.length; i++) {
            var face = faces[i];
            if (face[4] > 4) {
                // Get the coordinates and dimensions of the face
                var x = face[0]; // Adjusted x-coordinate for canvas offset
                var y = face[1];// Adjusted y-coordinate for canvas offset
                var faceWidth = face[2];
                var faceHeight = face[3];

    
                // Apply pixelate effect to the temporary image
                image(flower, x+482, y+640, faceWidth*1.4, faceHeight*0.8);
            }
        }
    //if face swap effect
    } else if (currentEffect === 'faceSwap'){
        image(snapshot, 500, 670, w, h);
        //create variables for width, height, x and y positions for face 1 and 2
        var face1x;
        var face1x;
        var face1w;
        var face1h;
        var face2x;
        var face2y;
        var face2w;
        var face2h;

        // Detect faces in the snapshot
        faces = detectFaces(snapshot);
        if (faces.length === 2){
            // Loop through each detected face
            for (var i = 0; i < faces.length; i++) {
                var face = faces[i];
                if (face[4] > 4) {
                    // Get the coordinates and dimensions of the face
                    var x = face[0]; // Adjusted x-coordinate for canvas offset
                    var y = face[1];// Adjusted y-coordinate for canvas offset
                    var faceWidth = face[2];
                    var faceHeight = face[3];
                    
                    if (i === 0){
                        //save face 1
                        var faceImage1 = snapshot.get(x, y, faceWidth, faceHeight);
                        face1x = x;
                        face1y = y;
                        face1w = faceWidth;
                        face1h = faceHeight;
                    } else if(i === 1){
                        //save face 2
                        var faceImage2 = snapshot.get(x, y, faceWidth, faceHeight);
                        face2x = x;
                        face2y = y;
                        face2w = faceWidth;
                        face2h = faceHeight;
                    }
                }
            }
            //swap two faces
            image(faceImage2, face1x+500, face1y+670, face1w, face1h);
            image(faceImage1, face2x+500, face2y+670, face2w, face2h);

        }
        else{
            console.log('face swap only works with 2 faces.')
        }
    } 
}


//detect faces
function detectFaces(snapshot){
    var faceImg = createImage(w,h);
    faceImg.copy(snapshot, 0, 0, w, h, 0, 0, w, h);
    return detector.detect(faceImg.canvas);
}


//function to blur image
function blurImage(img, blurRadius) {

    // Create a new image to store the blurred result
    var blurredImg = createImage(img.width, img.height);

    // Load pixels for both images
    img.loadPixels();
    blurredImg.loadPixels();

    // Loop through each pixel in the image
    for (var x = 0; x < img.width; x++) {
        for (var y = 0; y < img.height; y++) {
            // Initialize the total color values
            var totalRed = 0, totalGreen = 0, totalBlue = 0;

            // Loop through neighboring pixels within the blur radius
            for (var i = -blurRadius; i <= blurRadius; i++) {
                for (var j = -blurRadius; j <= blurRadius; j++) {
                    // Get the pixel coordinates (wrap around edges)
                    var px = constrain(x + i, 0, img.width - 1);
                    var py = constrain(y + j, 0, img.height - 1);

                    // Get the color components of the surrounding pixel
                    var index = (px + py * img.width) * 4;
                    var r = img.pixels[index];
                    var g = img.pixels[index + 1];
                    var b = img.pixels[index + 2];

                    // Accumulate color values
                    totalRed += r;
                    totalGreen += g;
                    totalBlue += b;
                }
            }

            // Calculate the average color
            var avgRed = totalRed / ((2 * blurRadius + 1) * (2 * blurRadius + 1));
            var avgGreen = totalGreen / ((2 * blurRadius + 1) * (2 * blurRadius + 1));
            var avgBlue = totalBlue / ((2 * blurRadius + 1) * (2 * blurRadius + 1));

            // Set the blurred pixel color in the new image
            var index = (x + y * img.width) * 4;
            blurredImg.pixels[index] = avgRed;
            blurredImg.pixels[index + 1] = avgGreen;
            blurredImg.pixels[index + 2] = avgBlue;
            blurredImg.pixels[index + 3] = 255; // Alpha value
        }
    }

    // Update the pixels for the blurred image
    blurredImg.updatePixels();

    // Return the blurred image
    return blurredImg;
}
//function to pixelate image
function pixelate(img) {
    // Create a new image to store the pixelated result
    var pixelatedImg = createImage(img.width, img.height);
    pixelatedImg.loadPixels();
    
    var blockSize = 5; // Adjust this value to change the pixelation level

    // Loop through each block
    for (var y = 0; y < img.height; y += blockSize) {
        for (var x = 0; x < img.width; x += blockSize) {
            // Calculate the average pixel intensity of the block
            var sumIntensity = 0;
            var count = 0;
            for (var j = 0; j < blockSize; j++) {
                for (var i = 0; i < blockSize; i++) {
                    var px = x + i;
                    var py = y + j;
                    if (px < img.width && py < img.height) {
                        var intensity = img.get(px, py)[0]; // Greyscale value
                        sumIntensity += intensity;
                        count++;
                    }
                }
            }
            var averageIntensity = sumIntensity / count;

            // Paint the entire block using the average pixel intensity
            for (var j = 0; j < blockSize; j++) {
                for (var i = 0; i < blockSize; i++) {
                    var px = x + i;
                    var py = y + j;
                    if (px < img.width && py < img.height) {
                        pixelatedImg.set(px, py, color(averageIntensity)); // Set pixel color
                    }
                }
            }
        }
    }
    
    pixelatedImg.updatePixels();
    return pixelatedImg;
}
