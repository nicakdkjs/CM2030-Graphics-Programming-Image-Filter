/* REPORT:
My findings for each colour channel are the noise differences. Depending on the surroundings and image colours, 
some colours are noisier than the others and some have a brighter contrast even though the sliders are at the same values.

I faced certain problems with the face detection as I had some issues getting the correct face detection area and getting
the rectangle to be drawn at the correct area, I spent weeks working on it and analysed several ways to write the face 
detection code, and eventually managed to get it working successfully. 

Yes, I managed to successfully complete the project, however one change I will make if I had more time is to improve 
my extensions by adding more ideas and making my game more challenging. I will add more fruits with abilities like pausing
the timer, doubling and halving the user’s score. I will also make these special ability fruits less common and harder to 
come by, and add a highscore board consisting of the past high scores in a ranking system.

My extensions include a fruit catching game where the user’s face is replaced by a fruit basket and there is a countdown timer 
of 60 seconds. The objective of the game is to catch as many falling fruits as you can, within 60 seconds, by moving your face 
around. When the timer ends, the game will end and a ‘Game Over’ message and the user’s score will be shown. The game will start 
when the user clicks on the ‘Play’ button and each caught fruit will gain the user a point. However, there are two objects, the 
rotten apple and the bomb, the rotten apple will cause the user to lose a point, and the bomb will end the game. There are also 
two special fruits, the apple which will gain the user 2 points and the banana which will add 5 more seconds to the timer. 
The user can click on the ‘Play’ button again, which will reset the score and the timer. I believe my game is unique as it 
offers an immersive and engaging gaming experience. The inclusion of various types of fruits with different effects adds 
complexity and strategy to the game. The countdown timer and scoring system also adds a competitive element to the game, 
leading to replayability and competition.

I also added more filters such as the invert, sepia tone, emboss, posterize, film and vignette filters, and filters in my 
face detection code, accessed by pressing the keys ‘6’, ‘7’,’8’, ‘9’. The filters are a hat, rabbit ears, dog ears, flower 
crown which adds images at the user’s head area. The ‘0’ key is a face swap filter which requires 2 detected faces to work. 
It performs a face swap where each face will be swapped to the other detected face area. I believe these filters are unique 
as it enhances the user’s experience, allows the user to personalise their interactions and provides additional creativity 
and entertainment value. */

// variables for webcam and snapshot
var video;
var snapshotButton;
var snapshot;
var undoButton;
var undo = true;

var thresholdRed = 127; // Initial threshold value for red channel
var thresholdGreen = 127; // Initial threshold value for green channel
var thresholdBlue = 127; // Initial threshold value for blue channel

var thresholdYCbCr = 127; // Initial threshold value for CMYK 
var thresholdHSL = 127; // Initial threshold value for HSL 
// Slider variables
var sliderRed, sliderGreen, sliderBlue, sliderYCbCr, sliderHSL;

    
//face detection
var detector;
var classifier = objectdetect.frontalface;
var faces;
var face;

//set current face detection filter to none
var currentEffect = 'none'; 


// Game variables
var playButton;
var play;
let playerX, playerY; // Player position
let fruits = []; // Array to store falling fruits
let score = 0;
var startGame = false;
let gameover = false;
var apple, banana, grape, watermelon, bomb, rottenApple, gameOver;

//timer for game
var startTime = 0;
var timer = 60;
var elapsedTime = 0;
var remainingTime = 60;
//set game start time

function preload(){
    hat = loadImage("assets/hat.png");
    ears = loadImage("assets/ears.png");
    dog = loadImage("assets/dog_ears.png");
    flower = loadImage("assets/flower.png");

    apple = loadImage('assets/apple.png')
    rottenApple = loadImage('assets/rotten apple.png')
    grape = loadImage('assets/grape.png')
    banana = loadImage('assets/banana.png')
    watermelon = loadImage('assets/watermelon.png')
    bomb = loadImage('assets/bomb.png')
    gameOver = loadImage('assets/gameover.png')
    basket = loadImage('assets/basket.png')

}




function setup() {
    createCanvas(800, 1400);
    pixelDensity(1);

    //create video
    video = createCapture(VIDEO);
    video.hide();

    //setup face detection
    setupFaceDetect();
    
    //create buttons for snapshot, undo and play button
    snapshotButton = createButton('Take Snapshot');
    snapshotButton.position(40, 20);
    snapshotButton.mousePressed(takeSnapshot);

    undoButton = createButton('Undo Snapshot');
    undoButton.position(150,20);
    undoButton.mousePressed(undoSnapshot);

    playButton = createButton('Play');
    playButton.position(40,1108);
    playButton.mousePressed(play);
   
    startTime = millis(); // Get the current time in milliseconds


}


function draw() {
    background(255);
    


    if (!undo) {
        //update positions of sliders
        if (sliderRed) {
            thresholdRed = sliderRed.value();
            thresholdGreen = sliderGreen.value();
            thresholdBlue = sliderBlue.value();
            thresholdYCbCr = sliderYCbCr.value();
            thresholdHSL = sliderHSL.value();
        }

        push();
        //mirror image
        translate(700, 10);
        scale(-1,1,1);
        
        snapshot.resize(160, 120);
        image(snapshot, 500, 50, snapshot.width, snapshot.height);


        //greyscale filter
        image(greyScaleBrightness(snapshot), 300, 50, snapshot.width, snapshot.height);

        // Red channel
        let redChannelImg = extractChannel(snapshot, 'red');
        image(redChannelImg, 500, 200, snapshot.width, snapshot.height);

        // Green channel
        let greenChannelImg = extractChannel(snapshot, 'green');
        image(greenChannelImg, 300, 200, snapshot.width, snapshot.height);

        // Blue channel
        let blueChannelImg = extractChannel(snapshot, 'blue');
        image(blueChannelImg, 100, 200, snapshot.width, snapshot.height);

        // Thresholded red channel
        let thresholdedRed = thresholdChannel(redChannelImg, thresholdRed, 'red');
        image(thresholdedRed, 500, 350, snapshot.width, snapshot.height);

        // Thresholded green channel
        let thresholdedGreen = thresholdChannel(greenChannelImg, thresholdGreen, 'green');
        image(thresholdedGreen, 300, 350, snapshot.width, snapshot.height);

        // Thresholded blue channel
        let thresholdedBlue = thresholdChannel(blueChannelImg, thresholdBlue, 'blue');
        image(thresholdedBlue, 100, 350, snapshot.width, snapshot.height);

        //web cam image repeated
        image(snapshot, 500, 520, snapshot.width, snapshot.height);

        //colour space 1
        image(applyYCbCrFilter(snapshot), 300, 520, snapshot.width, snapshot.height);

        //colour space 2
        image(rgbToHsl(snapshot), 100, 520, snapshot.width, snapshot.height);

        //face detection
        drawFaceDetect();
        
        //threshold for colour space 1
        image(applyThresholdYCbCrFilter(applyYCbCrFilter(snapshot)), 300, 670, snapshot.width, snapshot.height);

        //threshold for colour space 2
        image(thresholdHsl(rgbToHsl(snapshot)), 100, 670, snapshot.width, snapshot.height);
        
        //invert picture 
        image(invertColors(snapshot), 500, 820, snapshot.width, snapshot.height);
        
        //sepia tone
        image(applySepiaTone(snapshot), 300, 820, snapshot.width, snapshot.height);

        //emboss filter
        image(applyEmbossFilter(snapshot), 100, 820, snapshot.width, snapshot.height);

        //posterize filter
        image(applyPosterizeFilter(snapshot,2),500,970,snapshot.width, snapshot.height);

        //crossProcess filter
        image(applyFilmFilter(snapshot),300, 970, snapshot.width, snapshot.height);
        //vignette filter
        image(applyVignette(snapshot), 100, 970, snapshot.width, snapshot.height);
        pop();

        
        //game
        if (startGame){
            gameStart();
        }
        
        // Check if the game is over
        if (gameover) {
            // Display game over message
            image(gameOver, 67, 1150, 100,100);
            textSize(25);
            fill(0);
            //display score
            text("Score: " + score, 67, 1162);
        }


    } else{
        push();
        //mirror image
        translate(700, 10);
        scale(-1,1,1);
        image(video, 50,0, video.width, video.height);
        pop();
    }

}
//if snapshot button pressed
function takeSnapshot() {
    //set undo to false
    undo = false;
    snapshot = video.get(); // Take a snapshot
    video = createCapture(VIDEO);
    video.hide();    

    // Create sliders and set their initial positions
    sliderRed = createSlider(0, 255, thresholdRed);
    sliderRed.position(55, 485);

    sliderGreen = createSlider(0, 255, thresholdGreen);
    sliderGreen.position(255, 485);

    sliderBlue = createSlider(0, 255, thresholdBlue);
    sliderBlue.position(455, 485);

    sliderYCbCr = createSlider(0, 255, thresholdYCbCr);
    sliderYCbCr.position(255, 805);

    sliderHSL = createSlider(0, 255, thresholdHSL);
    sliderHSL.position(455, 805);
}

//if undo button pressed
function undoSnapshot(){
    //set undo and gameover to false
    undo = true;
    gameover = false;

    // Remove sliders
    if (sliderRed) {
        sliderRed.remove();
        sliderGreen.remove();
        sliderBlue.remove();
        sliderYCbCr.remove();
        sliderHSL.remove();
    }
}

//if play button clicked
function play(){
    //reset score and timer
    //set gameover to false and startGame to true
    //call gameStart
    score = 0;
    gameover = false;
    startGame = true;
    resetTimer();
    gameStart();
}




function keyPressed() {
    // Check which key is pressed and update the current effect accordingly
    if (key === '1') {
        currentEffect = 'none';
    } else if (key === '2') {
        currentEffect = 'grayscale';
    } else if (key === '3') {
        currentEffect = 'blurred';
    } else if (key === '4') {
        currentEffect = 'ycbcr';
    } else if (key === '5') {
        currentEffect = 'pixelate';
    } else if (key === '6'){
        currentEffect = 'Hat';
    } else if (key === '7'){
        currentEffect = 'ears';
    } else if (key === '8'){
        currentEffect = 'dog';
    } else if (key === '9'){
        currentEffect = 'flower';
    } else if (key === '0'){
        currentEffect = 'faceSwap';
    } 
}
  
function gameStart(){
    //set startgame to true
    startGame = true;
    let ground = 1240; // Ground position

    // Calculate elapsed time
    elapsedTime = millis() - startTime;
    
    // Calculate remaining time
    remainingTime = timer - floor(elapsedTime / 1000);
        
    //check if remaining time less than or equal to 0
    if (remainingTime <= 0){
        //set gameover to true and startgame to false
        gameover = true;
        startGame = false;
    }

    textSize(15);
    fill(0);
    //display score and timer
    text("Score: " + score, 42, 1145);
    text("Timer: " + remainingTime, 132, 1145);
    
    push();
    //mirror image
    translate(700, 10);
    scale(-1,1,1);


    // Check if it's time to create a new fruit
    if (frameCount % 15 === 0) { // Adjust the interval for creating new fruits
        // Create a new fruit object
        let fruit = {
            type: random(['apple', 'banana', 'grape', 'watermelon', 'bomb', 'rottenApple']),
            speed: random(1, 5),
            xPos: random(530, 630),
            yPos: 1140
        };
        fruits.push(fruit); // Add the new fruit to the array
    }

    // Update and display each falling fruit
    for (let i = fruits.length - 1; i >= 0; i--) {
        let fruit = fruits[i];
        // Display fruit based on its type
        switch (fruit.type) {
            case 'apple':
                image(apple, fruit.xPos, fruit.yPos, 30, 30);
                break;
            case 'banana':
                image(banana, fruit.xPos, fruit.yPos, 30, 20);
                break;
            case 'watermelon':
                image(watermelon, fruit.xPos, fruit.yPos, 30, 30);
                break;
            case 'grape':
                image(grape, fruit.xPos, fruit.yPos, 30, 30);
                break;
            case 'rottenApple':
                image(rottenApple, fruit.xPos, fruit.yPos, 30, 30);
                break;
            case 'bomb':
                image(bomb, fruit.xPos, fruit.yPos, 30, 30);
                break;
        }
        // Update fruit position
        fruit.yPos += fruit.speed;
        // Remove fruit if it reaches the ground
        if (fruit.yPos > ground) {
            fruits.splice(i, 1);
        }

        // Check for collision with player
        if (dist(fruit.xPos, fruit.yPos, playerX, playerY) < 25) {
            //if user caught bomb, game over
            if (fruit.type === 'bomb') {
                gameover = true;
                startGame = false;
                
            // if user caught rotten apple, 1 point deducted 
            } else if (fruit.type === 'rottenApple') {
                score--;
            // if user caught apple, 2 points added
            } else if (fruit.type === 'apple'){
                score += 2;
            } else if (fruit.type === 'banana'){
                timer += 5;
            } else {
                score++;
            }
            fruits.splice(i, 1); // Remove fruit
        }
    }
    pop();
}

//function to reset the timer
function resetTimer(){
    startTime = millis();
    elapsedTime = 0;
    timer = 60;
    remainingTime = 60;

}
