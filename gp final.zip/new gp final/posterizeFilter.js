
function applyPosterizeFilter(inputImage, levels) {
    let posterizedImage = inputImage.get();
    posterizedImage.loadPixels();

    // Define the color levels
    let colorLevels = levels;

    // Apply the posterize effect to each pixel
    for (let i = 0; i < posterizedImage.pixels.length; i += 4) {
        let r = posterizedImage.pixels[i];
        let g = posterizedImage.pixels[i + 1];
        let b = posterizedImage.pixels[i + 2];

        // Quantize the color space by dividing and multiplying back
        r = round(r / (255 / colorLevels)) * (255 / colorLevels);
        g = round(g / (255 / colorLevels)) * (255 / colorLevels);
        b = round(b / (255 / colorLevels)) * (255 / colorLevels);

        // Set the pixel with the new color values
        posterizedImage.pixels[i] = r;
        posterizedImage.pixels[i + 1] = g;
        posterizedImage.pixels[i + 2] = b;
    }

    posterizedImage.updatePixels();
    return posterizedImage;
}

