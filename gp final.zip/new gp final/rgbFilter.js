
// Function to update threshold value for red channel
function updateThresholdRed() {
    thresholdRed = this.value();
    
}

// Function to update threshold value for green channel
function updateThresholdGreen() {
    thresholdGreen = this.value();
}

// Function to update threshold value for blue channel
function updateThresholdBlue() {
    thresholdBlue = this.value();
}

    
// Function to apply thresholding to a channel
function thresholdChannel(inputImage, thresholdValue, channel) {
    let thresholded = inputImage.get();
    thresholded.loadPixels();
    inputImage.loadPixels();
    for(var y=0;y<inputImage.height;y++){
        for(var x=0;x<inputImage.width;x++){
            
            var pixelIndex = ((inputImage.width * y) + x)*4;
            var pixelRed = inputImage.pixels[pixelIndex + 0];
            var pixelGreen = inputImage.pixels[pixelIndex + 1];
            var pixelBlue = inputImage.pixels[pixelIndex + 2];
            
            //red channel
            if (channel === 'red') {
                if(thresholdRed>pixelRed){
                    pixelRed = 0;
                }
                thresholded.pixels[pixelIndex+0] = pixelRed;
                thresholded.pixels[pixelIndex+1] = 0;
                thresholded.pixels[pixelIndex+2] = 0;
                thresholded.pixels[pixelIndex+3] = 255;
            
            //green channel
            } else if (channel === 'green') {
                  if(thresholdGreen>pixelGreen){
                    pixelGreen = 0;
                }
                thresholded.pixels[pixelIndex+0] = 0;
                thresholded.pixels[pixelIndex+1] = pixelGreen;
                thresholded.pixels[pixelIndex+2] = 0;
                thresholded.pixels[pixelIndex+3] = 255;
            
            
            //blue channel
            } else if (channel === 'blue') {
                if(thresholdBlue>pixelBlue){
                    pixelBlue = 0;
                }
                thresholded.pixels[pixelIndex+0] = 0;
                thresholded.pixels[pixelIndex+1] = 0;
                thresholded.pixels[pixelIndex+2] = pixelBlue;
                thresholded.pixels[pixelIndex+3] = 255;
            
            }
        }
    }
    thresholded.updatePixels();
    return thresholded;
}
    
    

// Function to extract a specific channel (red, green, or blue) from an image
function extractChannel(inputImage, channel) {
    let extracted = inputImage.get();
    extracted.loadPixels();
    inputImage.loadPixels();
    for (let i = 0; i < inputImage.pixels.length; i += 4) {
        if (channel === 'red') {
            extracted.pixels[i] = inputImage.pixels[i];
            extracted.pixels[i+1] = 0;
            extracted.pixels[i+2] = 0;
            extracted.pixels[i+3] = 255;
        } else if (channel === 'green') {
            extracted.pixels[i] = 0;
            extracted.pixels[i+1] = inputImage.pixels[i+1];
            extracted.pixels[i+2] = 0;
            extracted.pixels[i+3] = 255;
        } else if (channel === 'blue') {
            extracted.pixels[i] = 0;
            extracted.pixels[i+1] = 0;
            extracted.pixels[i+2] = inputImage.pixels[i+2];
            extracted.pixels[i+3] = 255;
        }
    }
    extracted.updatePixels();
    return extracted;
}

