
function greyScaleBrightness(img) {
    var imgOut = img.get(); // Copy the input image

    imgOut.loadPixels();

    for (var x = 0; x < imgOut.width; x++) {
        for (var y = 0; y < imgOut.height; y++) {
            var index = (x + y * imgOut.width) * 4;

            var r = imgOut.pixels[index + 0];
            var g = imgOut.pixels[index + 1];
            var b = imgOut.pixels[index + 2];

            var gray = (r + g + b) / 3; // simple
            // var gray = r * 0.299 + g * 0.587 + b * 0.114; // LUMA ratios 

            // Increase brightness by 20%
            gray *= 1.2;

            // Ensure the value does not exceed 255
            gray = min(gray, 255);

            //code to prevent pixel intensity from exceeding 255
            imgOut.pixels[index + 0] = imgOut.pixels[index + 1] = imgOut.pixels[index + 2] = gray;
            imgOut.pixels[index + 3] = 255;
        }
    }
    imgOut.updatePixels();
    return imgOut;
}


function greyScale(img) {
    var imgOut = img.get(); // Copy the input image

    imgOut.loadPixels();

    for (var x = 0; x < imgOut.width; x++) {
        for (var y = 0; y < imgOut.height; y++) {
            var index = (x + y * imgOut.width) * 4;

            var r = imgOut.pixels[index + 0];
            var g = imgOut.pixels[index + 1];
            var b = imgOut.pixels[index + 2];

            var gray = (r + g + b) / 3; // simple
            // var gray = r * 0.299 + g * 0.587 + b * 0.114; // LUMA ratios 


            // Ensure the value does not exceed 255
            gray = min(gray, 255);

            //code to prevent pixel intensity from exceeding 255
            imgOut.pixels[index + 0] = imgOut.pixels[index + 1] = imgOut.pixels[index + 2] = gray;
            imgOut.pixels[index + 3] = 255;
        }
    }
    imgOut.updatePixels();
    return imgOut;
}

