
// Function to convert RGB image to HSL color space
function rgbToHsl(img) {
    var hslImg = img.get();
    hslImg.loadPixels();

    // Load image pixel values into array pixels
    img.loadPixels();

    for(var y = 0; y < img.height; y++){
        for(var x = 0; x < img.width; x++){

            var pixelIndex = ((img.width * y) + x) * 4;
            var pixelRed = img.pixels[pixelIndex + 0];
            var pixelGreen = img.pixels[pixelIndex + 1];
            var pixelBlue = img.pixels[pixelIndex + 2];
            
            let rgbColor = color(pixelRed, pixelGreen, pixelBlue);

            // Extract HSB values from the color object
            let h = hue(rgbColor);
            let s = saturation(rgbColor);
            let br = brightness(rgbColor);

            var hsl = [h, s, br];
            // Display hue as red, saturation as green, brightness as blue
            hslImg.pixels[pixelIndex + 0] = hsl[0] * 1.5; 
            hslImg.pixels[pixelIndex + 1] = hsl[1] * 1.5;
            hslImg.pixels[pixelIndex + 2] = hsl[2] * 2;
            hslImg.pixels[pixelIndex + 3] = 255;

        }
    }
    hslImg.updatePixels();
    return hslImg;
}

function updateThresholdHSL() {
    thresholdHSL = this.value();
}

// Function to apply thresholding to HSL image
function thresholdHsl(inputImage) {
    let thresholded = inputImage.get();
    thresholded.loadPixels();
    inputImage.loadPixels();
    for (let i = 0; i < inputImage.pixels.length; i += 4) {
        let h = inputImage.pixels[i] / 255; // Hue
        let s = inputImage.pixels[i + 1] / 255; // Saturation
        let l = inputImage.pixels[i + 2] / 255; // Lightness

        // Calculate brightness of the pixel (using lightness)
        let brightness = (Math.max(l, 0.5) + Math.min(l, 0.5)) / 2; // Adjust for correct brightness calculation

        // Apply threshold
        if (brightness > thresholdHSL / 255) {
            // Set pixel to white
            thresholded.pixels[i] = h * 255; // Hue
            thresholded.pixels[i + 1] = s * 255; // Saturation
            thresholded.pixels[i + 2] = l * 255; // Lightness
            thresholded.pixels[i + 3] = 255; // Alpha
        } else {
            // Set pixel to black
            thresholded.pixels[i] = 0; // Hue
            thresholded.pixels[i + 1] = 0; // Saturation
            thresholded.pixels[i + 2] = 0; // Lightness
            thresholded.pixels[i + 3] = 255; // Alpha
        }
    }
    thresholded.updatePixels();
    return thresholded;
}

