
function applySepiaTone(inputImage) {
    let sepiaImage = inputImage.get();
    sepiaImage.loadPixels();
    
    for (let i = 0; i < sepiaImage.pixels.length; i += 4) {
        let r = sepiaImage.pixels[i];
        let g = sepiaImage.pixels[i + 1];
        let b = sepiaImage.pixels[i + 2];

        // Calculate new RGB values for sepia tone effect
        let newR = (r * 0.393) + (g * 0.769) + (b * 0.189);
        let newG = (r * 0.349) + (g * 0.686) + (b * 0.168);
        let newB = (r * 0.272) + (g * 0.534) + (b * 0.131);

        // Ensure the transformed values stay within the valid range (0 to 255)
        newR = constrain(newR, 0, 255);
        newG = constrain(newG, 0, 255);
        newB = constrain(newB, 0, 255);

        // Update the pixel with the new RGB values
        sepiaImage.pixels[i] = newR;
        sepiaImage.pixels[i + 1] = newG;
        sepiaImage.pixels[i + 2] = newB;
    }

    sepiaImage.updatePixels();
    return sepiaImage;
}
