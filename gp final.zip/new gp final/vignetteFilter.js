function applyVignette(image) {
    let vignetteImg = image.get();
    vignetteImg.loadPixels();
    
    // Define the center of the image
    let centerX = image.width / 2;
    let centerY = image.height / 2;
    
    // Define the maximum distance from the center
    let maxDist = dist(0, 0, centerX, centerY);
    
    // Loop through each pixel
    for (let x = 0; x < image.width; x++) {
        for (let y = 0; y < image.height; y++) {
            // Calculate the distance from the center
            let d = dist(x, y, centerX, centerY);
            
            // Calculate the vignette amount based on the distance
            let vignetteAmount = map(d, 0, maxDist, 0, 1);
            
            // Apply the vignette effect by adjusting the alpha channel
            let pixelIndex = (y * image.width + x) * 4;
            vignetteImg.pixels[pixelIndex + 3] = vignetteAmount * 255;
        }
    }
    
    vignetteImg.updatePixels();
    return vignetteImg;
}
