function invertColors(img) {
    // Create a copy of the input image
    let invertedImg = img.get();
    invertedImg.loadPixels();

    // Iterate through each pixel in the image
    for (let i = 0; i < invertedImg.pixels.length; i += 4) {
        // Invert each color component by subtracting from 255
        invertedImg.pixels[i] = 255 - invertedImg.pixels[i]; // Red
        invertedImg.pixels[i + 1] = 255 - invertedImg.pixels[i + 1]; // Green
        invertedImg.pixels[i + 2] = 255 - invertedImg.pixels[i + 2]; // Blue
        // Alpha remains unchanged
    }

    // Update the image pixels
    invertedImg.updatePixels();

    // Return the modified image
    return invertedImg;
}
