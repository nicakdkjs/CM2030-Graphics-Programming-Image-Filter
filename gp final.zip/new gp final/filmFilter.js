function applyFilmFilter(image) {
    let filmImg = image.get();
    filmImg.loadPixels();

    // Loop through each pixel
    for (let i = 0; i < image.pixels.length; i += 4) {
        let r = filmImg.pixels[i]; // Red
        let g = filmImg.pixels[i + 1]; // Green
        let b = filmImg.pixels[i + 2]; // Blue

        // Apply film-like effect by adding noise to each color channel
        let noiseR = random(-50, 50); // Adjust noise range as desired
        let noiseG = random(-50, 50); // Adjust noise range as desired
        let noiseB = random(-50, 50); // Adjust noise range as desired

        // Apply noise to color channels
        r += noiseR;
        g += noiseG;
        b += noiseB;

        // Ensure color channels stay within valid range (0-255)
        r = constrain(r, 0, 255);
        g = constrain(g, 0, 255);
        b = constrain(b, 0, 255);

        // Update pixel with modified color channels
        filmImg.pixels[i] = r;
        filmImg.pixels[i + 1] = g;
        filmImg.pixels[i + 2] = b;
    }

    filmImg.updatePixels();
    return filmImg;
}
