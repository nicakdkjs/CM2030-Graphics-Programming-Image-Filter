
// Function to convert RGB image to YCbCr color space
function applyYCbCrFilter(inputImage) {
    let filteredImage = createImage(inputImage.width, inputImage.height); // Create a new image object with the same dimensions

    inputImage.loadPixels(); // Load pixel data of the input image
    filteredImage.loadPixels(); // Load pixel data of the new image

    // Iterate through each pixel in the input image
    for (let i = 0; i < inputImage.pixels.length; i += 4) {
        let R = inputImage.pixels[i];     // Red component of the pixel
        let G = inputImage.pixels[i + 1]; // Green component of the pixel
        let B = inputImage.pixels[i + 2]; // Blue component of the pixel

        // Apply YCbCr conversion
        let Y = 0.299 * R + 0.587 * G + 0.114 * B;
        let Cb = 128 + -0.169 * R - 0.331 * G + 0.500 * B;
        let Cr = 128 + 0.500 * R - 0.419 * G - 0.081 * B;

        // Ensure Y, Cb, and Cr are within valid range [0, 255]
        Y = constrain(Y, 0, 255);
        Cb = constrain(Cb, 0, 255);
        Cr = constrain(Cr, 0, 255);

        // Modify pixel values in the new image object
        filteredImage.pixels[i] = Y;
        filteredImage.pixels[i + 1] = Cb;
        filteredImage.pixels[i + 2] = Cr;
        filteredImage.pixels[i + 3] = 255; // Alpha channel remains unchanged
    }

    filteredImage.updatePixels(); // Update the pixel array of the new image object
    return filteredImage; // Return the new filtered image object
}



function updateThresholdYCbCr() {
    thresholdYCbCr = this.value();
}

// Function to apply threshold to YCbCr image
function applyThresholdYCbCrFilter(img) {
    img.loadPixels();
    for (let y = 0; y < img.height; y++) {
        for (let x = 0; x < img.width; x++) {
            // Get the index of the current pixel
            let index = (x + y * img.width) * 4;

            // Extract Y, Cb, and Cr components from the pixel
            let Y = img.pixels[index];
            let Cb = img.pixels[index + 1];
            let Cr = img.pixels[index + 2];

            // Apply threshold to the Y component
            if (Y > thresholdYCbCr) {
                img.pixels[index] = 255; // White
            } else {
                img.pixels[index] = 0; // Black
            }

            // Keep the Cb and Cr components unchanged
            img.pixels[index + 1] = Cb;
            img.pixels[index + 2] = Cr;
        }
    }
    img.updatePixels();
    return img;
}
