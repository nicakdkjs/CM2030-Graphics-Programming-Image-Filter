
function applyEmbossFilter(inputImage) {
    let embossImage = inputImage.get();
    embossImage.loadPixels();

    // Define the emboss convolution matrix
    let matrix = [
        [-2, -1, 0],
        [-1, 1, 1],
        [0, 1, 2]
    ];

    // Apply the convolution operation to each pixel
    for (let x = 1; x < embossImage.width - 1; x++) {
        for (let y = 1; y < embossImage.height - 1; y++) {
            let sumR = 0;
            let sumG = 0;
            let sumB = 0;

            // Convolve the pixel with the matrix
            for (let i = -1; i <= 1; i++) {
                for (let j = -1; j <= 1; j++) {
                    let index = ((y + j) * embossImage.width + (x + i)) * 4;
                    let weight = matrix[j + 1][i + 1];

                    sumR += inputImage.pixels[index] * weight;
                    sumG += inputImage.pixels[index + 1] * weight;
                    sumB += inputImage.pixels[index + 2] * weight;
                }
            }

            // Adjust pixel values to stay within valid range
            sumR = constrain(sumR + 128, 0, 255);
            sumG = constrain(sumG + 128, 0, 255);
            sumB = constrain(sumB + 128, 0, 255);

            // Set the pixel with the new values
            let pixelIndex = (y * embossImage.width + x) * 4;
            embossImage.pixels[pixelIndex] = sumR;
            embossImage.pixels[pixelIndex + 1] = sumG;
            embossImage.pixels[pixelIndex + 2] = sumB;
        }
    }

    embossImage.updatePixels();
    return embossImage;
}
